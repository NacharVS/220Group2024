﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Animation;

namespace WPFCharacters
{
    internal class Wizard : Character
    {
        private int _strength;
        private int _dexterity;
        private int _vitality;
        private int _inteligence;
        private int _maxstrength = 45;
        private int _maxvitality = 70;
        private int _maxinteligence = 250;
        private int _maxdexterity = 80;
        private int _health;
        private int _maxhealth;
        private int _mana;
        private int _maxmana;
        private int _physicaldamage;
        private int _armor;
        private int _magicdefence;
        private int _magicdamage;
        private int _criticalchance;
        private int _criticaldamage;
        public Wizard()
        {
            Strength = 15;
            Dexterity = 20;
            Inteligence = 35;
            Vitality = 15;
            addVitality();
        }
        public int Strength
        {
            get { return _strength; }
            set
            {
                _strength = value;
                double armor1 = 0;
                int armor = 0;
                if (_strength > _maxstrength)
                {
                    Strength = _maxstrength;
                }
                if (_strength < 15)
                    _strength = 15;
                for (int i = 0; i < _maxstrength; i++)
                {
                    armor1 += 0.5;
                    if (armor1 >= 1)
                    {
                        armor1--;
                        armor++;
                    }
                }
                PhysicalDamage = armor;
                addVitality();
            }
        }
        public int Vitality
        {
            get { return _vitality; }
            set
            {
                _vitality = value;
                if (_vitality > _maxvitality)
                {
                    _vitality = _maxvitality;
                }
                if (_vitality < 15)
                    _vitality = 15;
                addVitality();
            }
        }
        public int Inteligence
        {
            get { return _inteligence; }
            set
            {
                _inteligence = value;
                double manaleft = 0;
                int manapoints = 0;
                if (_inteligence > _maxinteligence)
                {
                    _inteligence = _maxinteligence;
                }
                if (_inteligence < 35)
                    _inteligence = 35;
                for (int i = 0; i < _inteligence; i++)
                {
                    manapoints += 1;
                    manaleft += 0.5;
                    if (manaleft >= 1)
                    { 
                        manapoints += 1;
                        manaleft -= 1;
                    }
                }
                MagicDamage = _inteligence;
                MagicDefence = _inteligence;
                MaxMana = manapoints;
            }
        }
        public int Dexterity
        {
            get { return _dexterity; }
            set
            {
                _dexterity = value;
                if (_dexterity > _maxdexterity)
                {
                    _dexterity = _maxdexterity;
                }
                if (_dexterity < 20)
                    _dexterity = 20;
                double criticalchance1 = 0;
                int criticalchance = 0;
                double criticaldamage1 = 0.000001;
                int criticaldamage = 0;
                for (int i = 0; i < _dexterity; i++)
                {
                    criticalchance1 += 0.2;
                    criticaldamage1 += 0.1;
                    if (criticalchance1 >= 1)
                    {
                        criticalchance1--;
                        criticalchance++;
                    }
                    if (criticaldamage1 >= 1)
                    {
                        criticaldamage++;
                        criticaldamage1--;
                    }
                }
                CriticalChance = criticalchance;
                CriticalDamage = criticaldamage;
                Armor = _dexterity;
            }
        }
        public int Health
        {
            get { return _health; }
            set { _health = value; }
        }
        public int MaxHealth
        {
            get { return _maxhealth; }
            set
            {
                if (Health == MaxHealth)
                {
                    _maxhealth = value;
                    _health = value;
                }
                else
                    _maxhealth = value;
            }
        }
        public int Mana
        {
            get { return _mana; }
            set
            {
                _mana = value;
                if (_mana > _maxmana)
                    _mana = _maxmana;
            }
        }

        public int MaxMana
        { 
            get { return _maxmana; }
            set
            {

                if (Mana == MaxMana)
                {
                    _maxmana = value;
                    _mana = _maxmana;
                }
                else
                    _maxmana = value;
            }
        }
        public int PhysicalDamage
        { 
            get { return _physicaldamage; }
            set { _physicaldamage = value; }
        }
        public int Armor
        { get { return _armor; }
            set 
            {
                _armor = value;    
            } 
        }
        public int MagicDefence
        { get { return _magicdefence; }
            set
            {
                _magicdefence  = value;
            }
        }  
        public int MagicDamage
        {
            get { return _magicdamage; }
            set { _magicdamage = value; }
        }
        public int CriticalChance
        {
            get { return _criticalchance; }
            set { _criticalchance = value; }
        }
        public int CriticalDamage
        { get { return _criticaldamage; }
            set
            {
                _criticaldamage = value;
            }
        }
        public void addVitality()
        {
            int healthpoints = 0;
            double healthpointsleft = 0.01;
            for (int i = 0; i < _vitality; i++)
            {
                healthpoints += 1;
                healthpointsleft += 0.4;
            }
            for (int i = 0; i < _strength; i++)
            {
                healthpointsleft += 0.2;
                if (healthpointsleft >= 1)
                {
                    healthpoints += 1;
                    healthpointsleft -= 1;
                }
            }
            MaxHealth = healthpoints;
        }
    }
}
