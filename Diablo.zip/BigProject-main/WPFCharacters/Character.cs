﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFCharacters
{
    internal interface Character
    {
        public int Strength
        { get; set; }
        public int Vitality
        { get; set; }
        public int Inteligence
        { get; set; }
        public int Dexterity
        { get; set; }
        public int Health
        { get; set; }
        public int MaxHealth
        { get; set; }
        public int Mana
        { get; set; }
        public int MaxMana
        { get; set; }
        public int PhysicalDamage
        { get; set; }
        public int Armor
        { get; set; }
        public int MagicDamage
        { get; set; }
        public int MagicDefence
        { get; set; }
        public int CriticalChance
        { get; set; }
        public int CriticalDamage
        { get; set; }


        public void addVitality(int points)
        {
            Vitality += points;
        }
    }
}
