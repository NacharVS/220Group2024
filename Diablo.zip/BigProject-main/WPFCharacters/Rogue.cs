﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFCharacters
{
    internal class Rogue : Character
    {
        private int _strength;
        private int _dexterity;
        private int _vitality;
        private int _Inteligence;
        private int _maxstrength = 65;
        private int _maxvitality = 80;
        private int _maxinteligence = 70;
        private int _maxdexterity = 250;
        private int _health;
        private int _maxhealth;
        private int _mana;
        private int _maxmana;
        private int _physicaldamage;
        private int _armor;
        private int _magicdefence;
        private int _magicdamage;
        private int _criticalchance;
        private int _criticaldamage;
        public Rogue()
        {
            Strength = 20;
            Dexterity = 30;
            Inteligence = 15;
            Vitality = 20;
            addVitality();
        }
        public int Strength
        {
            get { return _strength; }
            set
            {
                _strength = value;
                if (_strength > _maxstrength)
                {
                    Strength = _maxstrength;
                }
                if (_strength < 20)
                    _strength = 20;
                addVitality();
                addPhysicalDamage();
            }
        }
        public int Vitality
        {
            get { return _vitality; }
            set
            {
                _vitality = value;
                if (_vitality > _maxvitality)
                {
                    _vitality = _maxvitality;
                }
                if (_vitality < 20)
                    _vitality = 20;
                addVitality();
            }
        }
        public int Inteligence
        {
            get { return _Inteligence; }
            set 
            {
                _Inteligence = value;
                double manaleft = 0;
                int manapoints = 0;
                double magicdamage1 = 0;
                int magicdamage = 0;
                double magicdefence1 = 0;
                int magicdefence = 0;
                if (_Inteligence > _maxinteligence)
                {
                    _Inteligence = _maxinteligence;
                }
                if (_Inteligence < 15)
                    _Inteligence = 15;
                for (int i = 0; i < _Inteligence; i++)
                {
                    magicdamage1 += 0.2;
                    magicdefence1 += 0.5;
                    manapoints += 1;
                    manaleft += 0.2;
                    if (manaleft >= 1)
                    {
                        manapoints += 1;
                        manaleft -= 1;
                    }
                    if (magicdefence1 >= 1)
                    {
                        magicdefence++;
                        magicdefence1--;
                    }
                    if (magicdamage1 >= 1)
                    {
                        magicdamage++;
                        magicdamage1--;
                    }
                }
                MagicDamage = magicdamage;
                MagicDefence = magicdefence;
                MaxMana = manapoints;
            }
        }
        public int Dexterity
        {
            get { return _dexterity; }
            set
            {
                _dexterity = value;
                double armor1 = 0;
                int armor = 0;
                double criticalchance1 = 0;
                int criticalchance = 0;
                double criticaldamage1 = 0.000001;
                int criticaldamage = 0;
                if (_dexterity > _maxdexterity)
                {
                    _dexterity = _maxdexterity;
                }
                if (_dexterity < 30)
                    _dexterity = 30;
                for (int i = 0; i <_dexterity; i++)
                {
                    criticalchance1 += 0.2;
                    criticaldamage1 += 0.1;
                    armor++;
                    armor1 += 0.5;
                    if (armor1 >= 1)
                    {
                        armor++;
                        armor1--;
                    }
                    if (criticalchance1 >= 1)
                    {
                        criticalchance1--;
                        criticalchance++;
                    }
                    if (criticaldamage1 >= 1)
                    {
                        criticaldamage++;
                        criticaldamage1--;
                    }
                }
                CriticalChance = criticalchance;
                CriticalDamage = criticaldamage;
                Armor = armor;
                addPhysicalDamage();
            }
        }
        public int Health
        {
            get { return _health; }
            set { _health = value; }
        }
        public int MaxHealth
        {
            get { return _maxhealth; }
            set
            {
                if (Health == MaxHealth)
                {
                    _maxhealth = value;
                    _health = value;
                }
                else
                    _maxhealth = value;
            }
        }
        public int Mana
        {
            get { return _mana; }
            set
            {
                _mana = value;
                if (_mana > _maxmana)
                    _mana = _maxmana;
            }
        }

        public int MaxMana
        {
            get { return _maxmana; }
            set
            {

                if (Mana == MaxMana)
                {
                    _maxmana = value;
                    _mana = _maxmana;
                }
                else
                    _maxmana = value;
            }
        }
        public int PhysicalDamage
        {
            get { return _physicaldamage; }
            set { _physicaldamage = value; }
        }
        public int Armor
        {
            get { return _armor; }
            set
            {
                _armor = value;
            }
        }
        public int MagicDefence
        {
            get { return _magicdefence; }
            set
            {
                _magicdefence = value;
            }
        }
        public int MagicDamage
        {
            get { return _magicdamage; }
            set { _magicdamage = value; }
        }
        public int CriticalChance
        {
            get { return _criticalchance; }
            set { _criticalchance = value; }
        }
        public int CriticalDamage
        {
            get { return _criticaldamage; }
            set
            {
                _criticaldamage = value;
            }
        }
        public void addPhysicalDamage()
        {
            double physicaldamageb = 0;
            int physicaldamagec = 0;
            for (int i = 0; i < Dexterity; i++) 
            {
                physicaldamageb += 0.5;
                if (physicaldamageb >= 1)
                {
                    physicaldamagec++;
                    physicaldamageb--;
                }
            }
            for (int i = 0; i < Strength; i++)
            {
                physicaldamageb += 0.5;
                if (physicaldamageb >= 1)
                {
                    physicaldamagec++;
                    physicaldamageb--;
                }
            }
            PhysicalDamage = physicaldamagec;
        }
        public void addVitality()
        {
            int healthpoints = 0;
            double healthpointsleft = 0;
            for (int i = 0; i < _vitality; i++)
            {
                healthpoints += 1;
                healthpointsleft += 0.5;
                if (healthpointsleft >= 1)
                {
                    healthpoints += 1;
                    healthpointsleft -= 1;
                }
            }
            for (int i = 0; i < _strength; i++)
            {
                healthpointsleft += 0.5;
                if (healthpointsleft >= 1)
                {
                    healthpoints += 1;
                    healthpointsleft -= 1;
                }
            }
            MaxHealth = healthpoints;
        }
    }
}

