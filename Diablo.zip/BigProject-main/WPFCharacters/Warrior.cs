﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Xps.Serialization;

namespace WPFCharacters
{
    internal class Warrior : Character
    {
        private int _strength;
        private int _dexterity;
        private int _vitality;
        private int _inteligence;
        private int _maxstrength = 250;
        private int _maxvitality = 100;
        private int _maxinteligence = 50;
        private int _maxdexterity = 80;
        private int _health;
        private int _maxhealth;
        private int _mana;
        private int _maxmana;
        private int _physicaldamage;
        private int _armor;
        private int _magicdefence;
        private int _magicdamage;
        private int _criticalchance;
        private int _criticaldamage;
        public Warrior() 
            {
                Strength = 30;
                Dexterity = 15;
                Inteligence = 10;
                Vitality = 25;
                addVitality();
            }
        public int Strength
        { 
            get { return _strength; }
            set
            {
                _strength = value;
                PhysicalDamage = value;
                if (_strength > _maxstrength)
                {
                    _strength = _maxstrength;
                }
                if (_strength < 30)
                    _strength = 30;
                addVitality();
            }
        }
        public int Vitality
        {
            get { return _vitality; }
            set
            {
                _vitality = value;
                if (_vitality > _maxvitality)
                {
                    _vitality = _maxvitality;
                }
                if (_vitality < 25)
                    _vitality = 25;
                addVitality();
            }
        }    
        public int Inteligence
        {
            get { return _inteligence; }
            set
            {
                _inteligence = value;
                int manapoints = 0;
                int magicdamage = 0;
                double magicdamage1 = 0;
                int magicdefence = 0;
                double magicdefence1 = 0;
                if (_inteligence > _maxinteligence)
                {
                    _inteligence = _maxinteligence;
                }
                if (_inteligence < 10)
                    _inteligence = 10;
                for (int i = 0; i < _inteligence; i++)
                {
                    manapoints++;
                    magicdamage1 += 0.2;
                    magicdefence1 += 0.5;
                    if (magicdamage1 >= 1)
                    {
                        magicdamage++;
                        magicdamage1--;
                    }
                    if (magicdefence1 >= 1)
                    {
                        magicdefence++;
                        magicdefence1--;
                    }
                }
                MagicDefence = magicdefence;
                MagicDamage = magicdamage;
                MaxMana = manapoints;
            }
        }
        public int Dexterity
        {
            get { return _dexterity; }
            set
            {
                _dexterity = value;
                int criticalchance = 0;
                double criticalchance1 = 0;
                int criticaldamage = 0;
                double criticaldamage1 = 0;
                if (_dexterity > _maxdexterity)
                {
                    _dexterity = _maxdexterity;
                }
                if (_dexterity < 15)
                    _dexterity = 15;
                Armor = _dexterity;
                for (int i = 0; i <= _dexterity; i++)
                {
                    criticalchance1 += 0.2;
                    criticaldamage1 += 0.1;
                    if (criticalchance1 >= 1)
                    {
                        criticalchance++;
                        criticalchance1--;
                    }
                    if (criticaldamage1 >= 1)
                    {
                        criticaldamage++;
                        criticaldamage1--;
                    }
                }
                CriticalChance = criticalchance;
                CriticalDamage = criticaldamage;
            }
        }
        public int Health
        {
            get { return _health; }
            set { _health = value; }
        }
        public int MaxHealth
        {
            get { return _maxhealth; }
            set
            {
                if (Health == MaxHealth)
                {
                    _maxhealth = value;
                    _health = value;
                }
                else
                    _maxhealth = value;
            }
        }
        public int Mana
        {
            get { return _mana; }
            set
            {
                _mana = value;
                if (_mana > _maxmana)
                    _mana = _maxmana;
            }
        }

        public int MaxMana
        {
            get { return _maxmana; }
            set
            {

                if (Mana == MaxMana)
                {
                    _maxmana = value;
                    _mana = _maxmana;
                }
                else
                    _maxmana = value;
            }
        }
        public int PhysicalDamage
        {
            get { return _physicaldamage; }
            set { _physicaldamage = value; }
        }
        public int Armor
        {
            get { return _armor; }
            set
            {
                _armor = value;
            }
        }
        public int MagicDefence
        {
            get { return _magicdefence; }
            set
            {
                _magicdefence = value;
            }
        }
        public int MagicDamage
        {
            get { return _magicdamage; }
            set { _magicdamage = value; }
        }
        public int CriticalChance
        {
            get { return _criticalchance; }
            set { _criticalchance = value; }
        }
        public int CriticalDamage
        {
            get { return _criticaldamage; }
            set
            {
                _criticaldamage = value;
            }
        }
        public void addVitality()
        {
            int healthpoints = 0;
            for (int i = 0; i < _vitality; i++)
            {
                healthpoints += 2;
            }
            for (int i = 0; i < _strength; i++)
            {
                healthpoints++;
            }
            MaxHealth = healthpoints;
        }
    }
}
